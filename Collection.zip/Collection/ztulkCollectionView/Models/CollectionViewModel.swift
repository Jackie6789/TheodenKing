//
//  CollectionViewModel.swift
//  ztulkCollectionView
//
//  Created by 郑云鲲 on 2023/3/7.
//

import Foundation

struct HorizontalModel {
    var imageId: Int
}

struct VerticalModel {
    var imageId: Int
}
