//
//  ViewController.swift
//  ztulkCollectionView
//
//  Created by 郑云鲲 on 2023/3/7.
//

import UIKit
import SnapKit

class ViewController: UIViewController {
    
    private let sections = ["Scenery", "Landscape"]
    
    private var sceneryModels: [HorizontalModel] = [
        .init(imageId: 1),
        .init(imageId: 2),
        .init(imageId: 3),
        .init(imageId: 4),
        .init(imageId: 5)
    ]
    
    private var landscapeModels: [VerticalModel] = [
        .init(imageId: 1),
        .init(imageId: 2),
        .init(imageId: 3),
        .init(imageId: 4),
        .init(imageId: 5),
        .init(imageId: 6),
        .init(imageId: 7)
    ]
    
    private var myCollectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        let layout = createLayout()
        
        myCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        
        myCollectionView.register(HorizontalCollectionViewCell.self, forCellWithReuseIdentifier: HorizontalCollectionViewCell.identifier)
        myCollectionView.register(VerticalCollectionViewCell.self, forCellWithReuseIdentifier: VerticalCollectionViewCell.identifier)
        myCollectionView.showsVerticalScrollIndicator = true
        myCollectionView.showsHorizontalScrollIndicator = true
        
        view.addSubview(myCollectionView)
        
        myCollectionView.snp.makeConstraints { make in
            make.center.width.height.equalToSuperview()
        }
        
        myCollectionView.delegate = self
        myCollectionView.dataSource = self
        
    }
    
    private func createLayout() -> UICollectionViewLayout {
        let layout = UICollectionViewCompositionalLayout { sectionId, layoutEnvironment in
            if sectionId == 0 {
                let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1), heightDimension: .fractionalWidth(1))
                let item = NSCollectionLayoutItem(layoutSize: itemSize)
                let groupSize = NSCollectionLayoutSize(widthDimension: .absolute(350), heightDimension: .absolute(350))
                let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .groupPagingCentered
                section.interGroupSpacing = 10
                section.contentInsets = .init(top: 0, leading: 0, bottom: 0, trailing: 0)
                return section
            } else {
                let item = NSCollectionLayoutItem(layoutSize: .init(widthDimension: .fractionalWidth(1.0), heightDimension: .fractionalWidth(2.0)))
                let group = NSCollectionLayoutGroup.vertical(layoutSize: .init(widthDimension: .absolute(110), heightDimension: .fractionalHeight(2.0)), subitems: [item])
                let section = NSCollectionLayoutSection(group: group)
                section.orthogonalScrollingBehavior = .none
                section.interGroupSpacing = 10
                section.contentInsets = .init(top: 30, leading: 20, bottom: 30, trailing: 20)
                return section
            }
        }
        return layout
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return sections.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let sectionName = sections[section]
        if sectionName == "Scenery" {
            return sceneryModels.count
        } else if sectionName == "Landscape" {
            return landscapeModels.count
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let sectionName = sections[indexPath.section]
        if sectionName == "Scenery" {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HorizontalCollectionViewCell.identifier, for: indexPath) as! HorizontalCollectionViewCell
            let model = sceneryModels[indexPath.item]
            cell.setContent(imageName: "scenery1-\(model.imageId)")
            return cell
        } else if sectionName == "Landscape" {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VerticalCollectionViewCell.identifier, for: indexPath) as! VerticalCollectionViewCell
            let model = landscapeModels[indexPath.item]
            cell.setContent(imageName: "scenery2-\(model.imageId)")
            return cell
        } else {
            return UICollectionViewCell()
        }
    }
}

