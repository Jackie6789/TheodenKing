//
//  HorizontalCollectionViewCell.swift
//  ztulkCollectionView
//
//  Created by 郑云鲲 on 2023/3/7.
//

import UIKit
import SnapKit

class HorizontalCollectionViewCell: UICollectionViewCell {
    public static let identifier = "HorizontalCollectionViewCell"
    
    public var imageView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 20
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50)
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.height.equalTo(250)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(code:) has not been implemented")
    }
    
    func setContent(imageName name: String) {
        imageView.image = UIImage(named: name)
    }
}
