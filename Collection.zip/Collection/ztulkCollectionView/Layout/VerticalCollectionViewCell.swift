//
//  VerticalCollectionViewCell.swift
//  ztulkCollectionView
//
//  Created by 郑云鲲 on 2023/3/7.
//
//
import UIKit

class VerticalCollectionViewCell: UICollectionViewCell {
    public static let identifier = "VerticalCollectionViewCell"

    public var imageView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 20
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview()
            make.width.equalTo(350)
            make.height.equalTo(200)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setContent(imageName name: String) {
        imageView.image = UIImage(named: name)
    }

}
