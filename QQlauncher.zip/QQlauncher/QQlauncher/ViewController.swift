//
//  ViewController.swift
//  QQlauncher
//
//  Created by 郑云鲲~ on 2023/3/7.
//

import UIKit
import SnapKit

let myLeftView = UIImageView()

class ViewController: UIViewController {
    
    let imageView = UIImageView()
    let accountText = UITextField()
    let codeText = UITextField()
    let entryButton = UIButton()
    
    let screenWidth = UIScreen.main.bounds.width
    let screenHeight = UIScreen.main.bounds.height

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupImage()
        
        setupAccount()
        
        setupCode()
        
        setupButton()
        
        textFieldDidChangeSelection(accountText)
        
    }
    
    func setupImage() {
        let qqImage = UIImage(named: "QQlaucher")
        imageView.image = qqImage
        
        imageView.frame = CGRect(x: screenWidth / 2 - 105, y: screenHeight / 8, width: 210, height: 95)
        
        view.addSubview(imageView)
    }
    
    func setupAccount() {
        view.addSubview(accountText)
        accountText.placeholder = ""
        accountText.font = .systemFont(ofSize: 27)
        accountText.layer.cornerRadius = 38
        accountText.keyboardType = .emailAddress
        accountText.textColor = .black
        accountText.textAlignment = .center
        
        accountText.backgroundColor = UIColor(red: 240 / 255, green: 240 / 255, blue: 240 / 255, alpha: 1.0)
        
        accountText.snp.makeConstraints { make in
            make.top.equalTo(imageView).offset(150)
            make.left.equalToSuperview().offset(30)
            make.right.equalToSuperview().offset(-30)
            make.height.equalTo(73)
        }
        
        accountText.delegate = self
        
        myLeftView.image = UIImage(named: "picture")
        view.addSubview(myLeftView)
        myLeftView.frame = CGRect(x: screenWidth / 5 - 40, y: screenHeight / 3 - 22, width: 60, height: 60)
        myLeftView.layer.masksToBounds = true
        myLeftView.layer.cornerRadius = 30
        myLeftView.isHidden = true
    }
    
    func setupCode() {
        view.addSubview(codeText)
        codeText.placeholder = ""
        codeText.font = .systemFont(ofSize: 27)
        codeText.layer.cornerRadius = 38
        codeText.keyboardType = .emailAddress
        codeText.textColor = .black
        codeText.textAlignment = .center
        
        codeText.backgroundColor = UIColor(red: 240 / 255, green: 240 / 255, blue: 240 / 255, alpha: 1.0)
        codeText.isSecureTextEntry = true
        
        codeText.snp.makeConstraints { make in
            make.top.equalTo(accountText).offset(95)
            make.left.equalToSuperview().offset(30)
            make.right.equalToSuperview().offset(-30)
            make.height.equalTo(73)
        }
    }
    
    func setupButton() {
        view.addSubview(entryButton)
        
        entryButton.snp.makeConstraints { make in
            make.top.equalTo(codeText.snp.bottom).offset(40)
            make.left.equalToSuperview().offset(screenWidth / 2 - 40)
            make.right.equalToSuperview().offset(40 - screenWidth / 2)
            make.height.equalTo(80)
        }
        
        entryButton.backgroundColor = UIColor(red: 128 / 255, green: 201 / 255, blue: 249 / 255, alpha: 1.0)
        entryButton.layer.cornerRadius = 40
        entryButton.addTarget(self, action: #selector(loginIn), for: .touchUpInside)
        
        let arrow = UIImageView(image: UIImage(systemName: "arrow.right"))
        arrow.tintColor = .white
        view.addSubview(arrow)
        arrow.snp.makeConstraints { make in
            make.top.equalTo(entryButton.snp.top).offset(30)
            make.left.equalTo(entryButton.snp.left).offset(30)
            make.right.equalTo(entryButton.snp.right).offset(-30)
            make.height.equalTo(20)
        }
    }
    
    @objc func loginIn() {
        //ababababa
    }
}

extension ViewController: UITextFieldDelegate {
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if textField.text == "2240324227" {
            myLeftView.isHidden = false
        } else {
            myLeftView.isHidden = true
        }
    }
}

